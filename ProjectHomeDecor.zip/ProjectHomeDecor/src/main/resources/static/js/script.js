
// Подсчет суммы товаров в корзине (cart.html)

const summaryPriceVidget = document.querySelector('.summary__price-vidget');
let allProductsPrices = document.querySelectorAll('.cart-item__card');
const productCardsContainer = document.querySelector('.cart__items');

let summaryPrice = 0;

document.addEventListener('DOMContentLoaded', countSummPrice);

productCardsContainer.addEventListener('click', function(e) {
    if(e.target.classList.contains('cart-item__delete')) {
        //e.preventDefault();
        let deletedProduct = e.target.parentNode.parentNode;
        // console.log(deletedProduct);
        deletedProduct.style.display = 'none';
        deletedProduct.setAttribute("data-price", '0');
        countSummPrice();
    }
});

function countSummPrice() {
    summaryPrice = 0;
    if (allProductsPrices.length > 0) {
        for (let i = 0; i < allProductsPrices.length; i++) {
            let itemPrice = parseFloat(allProductsPrices[i].dataset['price']);
            // console.log(itemPrice);
            summaryPrice = parseFloat(summaryPrice + itemPrice);
        }
        summaryPriceVidget.innerHTML = `Суммарная стоимость товаров: $${summaryPrice}`;
        // console.log(summaryPrice);
    }
}



